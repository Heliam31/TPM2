char.c : le programme
prog.c : pour le test
